from rest_framework import viewsets
from . import models
from . import serializer
#from master.serializer import serializer


# class TourplanhdViewSets(viewsets.ModelViewSet):
#     queryset=models.Product.objects.all()
#     serializer_class=serializer.TourplanhdSerializer